# coding=utf-8
# Copyright 2020 The HuggingFace Datasets Authors and the current dataset script contributor.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""KLAID (Korean Legal Artificial Intelligence Datasets) benchmark."""

import json

import datasets

_KLAID_DESCRIPTION = """\
KLAID (Korean Legal Artificial Intelligence Datasets) is a dataset for the development of Korean legal artificial intelligence technology. This time we offer 1 task, which is legal judgment prediction(LJP).
"""

_DATA_USRs = {
    "ljp": "https://storage.googleapis.com/klaid/ljp/dataset/",
}

_LICENSE = "CC-BY-NC-ND-4.0"

class Klaid_Config(datasets.BuilderConfig):
    """BuilderConfig for KLAID"""

    def __init__(
        self,
        features,
        data_url,
        url,
        file_map,
        **kwargs,
    ):

        super(Klaid_Config, self).__init__(version=datasets.Version("1.0.0", ""), **kwargs)
        self.features = features
        self.data_url = data_url
        self.url = url
        self.file_map = file_map


class Klaid(datasets.GeneratorBasedBuilder):
    """Korean Legal Artificial Intelligence Datasets (KLAID) benchmark."""

    BUILDER_CONFIGS = [
        Klaid_Config(
            name="ljp",
            features={
                "laws_service_id": datasets.Value("int64"),
                "fact": datasets.Value("string"),
                "laws_service": datasets.Value("string"),
            },
            description="Training data for a classification model that predicts legal judgments from facts. The legal judgment of the data is applied as of 2022.10.15 (data may differ from the actual legal judgment due to subsequent amendments and deletions of the law).",
            data_url=_DATA_USRs["ljp"],
            url="https://klaid.net/",
            file_map={
                "train": "klaid_ljp_train.json",
            }
        ),
    ]

    def _info(self):
        return datasets.DatasetInfo(
            description=_KLAID_DESCRIPTION,
            features=datasets.Features(self.config.features),
            homepage=self.config.url,
            citation="",
            license=_LICENSE,
        )

    def _split_generators(self, dl_manager):
        dl_dir = {
            "train": dl_manager.download_and_extract(
                self.config.data_url + self.config.file_map['train']
            )
        }
        return [
            datasets.SplitGenerator(
                name=datasets.Split.TRAIN,
                gen_kwargs={
                    "data_file": dl_dir["train"],
                    "split": datasets.Split.TRAIN,
                }
            ),
        ]

    def _generate_examples(self, data_file, split):
        with open(data_file, encoding='utf-8') as f:
            f = json.load(f)
            for id_, row in enumerate(f):
                yield id_, {key: row[key] for key in row if key in self.config.features}